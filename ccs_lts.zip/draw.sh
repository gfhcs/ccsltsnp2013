dot -Tsvg lts.dot -o lts.svg 
